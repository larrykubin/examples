import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Locale;

public class NinjaPublicApiApacheClientExample {

	private static final DateTimeFormatter RFC1123_DATE_TIME_FORMATTER = DateTimeFormat.forPattern("EEE, dd MMM yyyy HH:mm:ss 'GMT'").withZoneUTC().withLocale(Locale.US);

	private static final String ACCESS_KEY_ID = "TF4STGMDR4H7AEXAMPLE";
	private static final String SECRET_ACCESS_KEY = "rEZWuXR0X1wX3autLTHIl2zX98I";

	public static void main(String[] args){
		try {
			String httpMethod = "GET";
			String contentMD5 = null;
			String contentType = null;
			Date requestDate = new Date();
			String canonicalPath = "/v1/customers";

			String stringToSign = getStringToSign(httpMethod, contentMD5, contentType, requestDate, canonicalPath);
			String signature = getSignature(SECRET_ACCESS_KEY, stringToSign);

			HttpGet request = new HttpGet("https://api.ninjarmm.com/v1/customers");
			request.setHeader("Date", RFC1123_DATE_TIME_FORMATTER.print(requestDate.getTime()));
			request.setHeader("Authorization", "NJ " + ACCESS_KEY_ID + ":" + signature);

			CloseableHttpResponse response = HttpClientBuilder.create().build().execute(request);
			
			String responseData = getResponseBody(response);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String getStringToSign(String httpMethod, String contentMD5, String contentType, Date requestDate, String canonicalPath){
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(httpMethod + "\n");
		stringBuilder.append(contentMD5 != null ? contentMD5 + "\n" : "\n");
		stringBuilder.append(contentType != null ? contentType + "\n" : "\n");
		stringBuilder.append(RFC1123_DATE_TIME_FORMATTER.print(requestDate.getTime()) + "\n");
		stringBuilder.append(canonicalPath);

		String stringToSign = stringBuilder.toString();
		return stringToSign;
	}

	private static String getSignature(String secretAccessKey, String stringToSign) throws Exception {
		String encodedString = Base64.encodeBase64String(stringToSign.getBytes("UTF-8")).replaceAll("\n", "").replaceAll("\r", "");
		Mac hmac = Mac.getInstance("HmacSHA1");
		hmac.init(new SecretKeySpec(secretAccessKey.getBytes("UTF-8"), "HmacSHA1"));
		String signature = Base64.encodeBase64String(hmac.doFinal(encodedString.getBytes("UTF-8"))).replaceAll("\n", "");
		return signature;
	}

	private static String getResponseBody(CloseableHttpResponse response) throws IOException {
		StringBuilder responseBody = new StringBuilder();

		if (response.getEntity() != null) {
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			String line;
			while ((line = rd.readLine()) != null) {
				responseBody.append(line);
			}
			rd.close();
		}

		return responseBody.toString();
	}
}

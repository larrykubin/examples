import org.apache.commons.codec.binary.Base64;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Date;
import java.util.Locale;

public class NinjaPublicApiJerseyClientExample {

	private static final DateTimeFormatter RFC1123_DATE_TIME_FORMATTER = DateTimeFormat.forPattern("EEE, dd MMM yyyy HH:mm:ss 'GMT'").withZoneUTC().withLocale(Locale.US);

	private static final String ACCESS_KEY_ID = "TF4STGMDR4H7AEXAMPLE";
	private static final String SECRET_ACCESS_KEY = "rEZWuXR0X1wX3autLTHIl2zX98I";

	public static void main(String[] args){
		try {
			String httpMethod = "GET";
			String contentMD5 = null;
			String contentType = null;
			Date requestDate = new Date();
			String canonicalPath = "/v1/customers";

			String stringToSign = getStringToSign(httpMethod, contentMD5, contentType, requestDate, canonicalPath);
			String signature = getSignature(SECRET_ACCESS_KEY, stringToSign);

			String responseData = JerseyClientBuilder.newClient()
					.target("https://api.ninjarmm.com/").path("v1").path("customers")
					.request().header("Date", requestDate).header("Authorization", "NJ " + ACCESS_KEY_ID + ":" + signature).get(String.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String getStringToSign(String httpMethod, String contentMD5, String contentType, Date requestDate, String canonicalPath){
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(httpMethod + "\n");
		stringBuilder.append(contentMD5 != null ? contentMD5 + "\n" : "\n");
		stringBuilder.append(contentType != null ? contentType + "\n" : "\n");
		stringBuilder.append(RFC1123_DATE_TIME_FORMATTER.print(requestDate.getTime()) + "\n");
		stringBuilder.append(canonicalPath);

		String stringToSign = stringBuilder.toString();
		return stringToSign;
	}

	private static String getSignature(String secretAccessKey, String stringToSign) throws Exception {
		String encodedString = Base64.encodeBase64String(stringToSign.getBytes("UTF-8")).replaceAll("\n", "").replaceAll("\r", "");
		Mac hmac = Mac.getInstance("HmacSHA1");
		hmac.init(new SecretKeySpec(secretAccessKey.getBytes("UTF-8"), "HmacSHA1"));
		String signature = Base64.encodeBase64String(hmac.doFinal(encodedString.getBytes("UTF-8"))).replaceAll("\n", "");
		return signature;
	}
}

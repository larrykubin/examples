import base64, hashlib, hmac, datetime, pytz

def get_rfc1123_datetime():
    offset = datetime.datetime.now(pytz.timezone('US/Pacific')).strftime('%z')

    return datetime.datetime.now().strftime("%a, %d %b %Y %H:%M:%S") + " " + offset

def get_string_to_sign(http_method, content_md5, content_type, request_date_time, canonical_path):
    string_to_sign = "%s\n%s\n%s\n%s\n%s" % (http_method, content_md5, content_type, request_date_time, canonical_path)
    return string_to_sign

def get_signature(secret_access_key, string_to_sign):
    secret_access_key = bytes(secret_access_key, "UTF-8")
    string_to_sign = base64.b64encode(bytes(string_to_sign, "UTF-8"))

    digester = hmac.new(secret_access_key, string_to_sign, hashlib.sha1)
    signature1 = digester.digest()
    signature2 = base64.b64encode(signature1)

    return str(signature2, 'UTF-8')

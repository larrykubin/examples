ACCESS_KEY_ID = "YOUR_ACCESS_KEY_ID"
SECRET_ACCESS_KEY = "YOUR_SECRET_ACCESS_KEY"

API_HOST = "https://api.ninjarmm.com"

DEVICES_URL = "/v1/devices"
DEVICE_URL = "/v1/device"
CUSTOMERS_URL = "/v1/customers"
ALERTS_URL = "/v1/alerts"


# list requests allow 10 requests every 10 minutes
NUM_LIST_REQUESTS_TO_MAKE = 1
SECONDS_BETWEEN_LIST_REQUESTS = 60

# entity requests allow 10 requests per minute
NUM_ENTITY_REQUESTS_TO_MAKE = 20
SECONDS_BETWEEN_ENTITY_REQUESTS = 6
import constants, requests, json
from helpers import *

request_datetime = get_rfc1123_datetime()

string_to_sign = get_string_to_sign("GET", "", "", request_datetime, constants.ALERTS_URL)

# create signature for request
signature = get_signature(constants.SECRET_ACCESS_KEY, string_to_sign)

# set headers
headers = {
    "Authorization": "NJ %s:%s" % (constants.ACCESS_KEY_ID, signature),
    "Date": request_datetime
}

# make the request, parse the JSON response and display it
response = requests.get("%s%s" % (constants.API_HOST, constants.ALERTS_URL), headers=headers)

print(response.status_code)
print(response.content)

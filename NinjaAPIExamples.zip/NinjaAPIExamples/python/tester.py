import constants, devices
import time, datetime, json, sys

def get_timestamp():
    utc_datetime = datetime.datetime.utcfromtimestamp(time.time()).strftime('%Y-%m-%dT%H:%M:%SZ')
    return utc_datetime

# get all devices 10 times
for i in range(constants.NUM_LIST_REQUESTS_TO_MAKE):
    print("==== get devices, request number %s at %s====" % (i + 1, get_timestamp()))
    response = devices.get_devices()
    if response.status_code == 200:
        response_data = json.loads(response.content)
        print("retrieved %s devices" % len(response_data))
    else:
        print("error fetching device list")
        print(response.status_code)
        sys.exit("failed fetching device list")

    #time.sleep(constants.SECONDS_BETWEEN_LIST_REQUESTS)

# use device id of last successful list request to test entity request
device_id = response_data[0]['id']

for i in range(constants.NUM_ENTITY_REQUESTS_TO_MAKE):
    print("==== get device, request number %s at %s====" % (i + 1, get_timestamp()))
    response = devices.get_device(device_id)

    if response.status_code == 200:
        response_data = json.loads(response.content)
        print(response_data)
        print(response_data['display_name'])
    else:
        print("error fetching device")
        print(response.status_code)
        print(response.content)

    time.sleep(constants.SECONDS_BETWEEN_ENTITY_REQUESTS)




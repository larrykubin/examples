import constants, requests, time, json, sys
from helpers import *

def get_device(id):
    request_datetime = get_rfc1123_datetime()
    device_url = "%s/%s" % (constants.DEVICES_URL, id)
    print(device_url)
    string_to_sign = get_string_to_sign("GET", "", "", request_datetime, device_url)
    signature = get_signature(constants.SECRET_ACCESS_KEY, string_to_sign)

    request_datetime = get_rfc1123_datetime()

    string_to_sign = get_string_to_sign("GET", "", "", request_datetime, device_url)

    # create signature for request
    signature = get_signature(constants.SECRET_ACCESS_KEY, string_to_sign)

    # set headers
    headers = {
        "Authorization": "NJ %s:%s" % (constants.ACCESS_KEY_ID, signature),
        "Date": request_datetime
    }

    # make the request, parse the JSON response and display it
    response = requests.get("%s%s" % (constants.API_HOST, device_url), headers=headers)

    return response

def get_devices():
    request_datetime = get_rfc1123_datetime()

    string_to_sign = get_string_to_sign("GET", "", "", request_datetime, constants.DEVICES_URL)

    # create signature for request
    signature = get_signature(constants.SECRET_ACCESS_KEY, string_to_sign)

    # set headers
    headers = {
        "Authorization": "NJ %s:%s" % (constants.ACCESS_KEY_ID, signature),
        "Date": request_datetime
    }

    # make the request, parse the JSON response and display it
    response = requests.get("%s%s" % (constants.API_HOST, constants.DEVICES_URL), headers=headers)

    return response




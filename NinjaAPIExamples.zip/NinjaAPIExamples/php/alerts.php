<?php
require('includes/constants.php');
require('includes/utils.php');
require('includes/CurlWrapper.php');

// Using CurlWrapper class to make HTTP requests
// https://github.com/svyatov/CurlWrapper/blob/master/CurlWrapper.php
$curl = new CurlWrapper();

// Create a datetime in RFC1123 format
$dateTime = new DateTime();
$requestDateTime = $dateTime->format(DATE_RFC1123);

// Create signature for request
$stringToSign = getStringToSign('GET', null, null, $requestDateTime, $ALERTS_URL);
$signature = getSignature($SECRET_ACCESS_KEY, $stringToSign);

// Add request headers
$curl->addHeader('Authorization', 'NJ ' . $ACCESS_KEY_ID . ':' . $signature);
$curl->addHeader('Date', $requestDateTime);

// make the request, parse the JSON response and display it	
$response = $curl->get($API_HOST . $ALERTS_URL);

print "<h3>Devices Response</h3>";
print "<pre>";
print_r(json_decode($response));
print "</pre>";
?>

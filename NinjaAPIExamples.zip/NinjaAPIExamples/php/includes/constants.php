<?php
// generate these under the integrations -> API tab
$ACCESS_KEY_ID = "YOURACCESSKEYHERE";
$SECRET_ACCESS_KEY = "YOURSECRETACCESSKEYHERE";

//  URL endpoints
$API_HOST = "https://api.ninjarmm.com";
$DEVICES_URL = "/v1/devices";
$CUSTOMERS_URL = "/v1/customers";
$ALERTS_URL = "/v1/alerts";
?>
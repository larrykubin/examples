<?php
function getStringToSign($httpMethod, $contentMD5, $contentType, $requestDateTime, $canonicalPath) {
	$stringToSign = sprintf("%s\n%s\n%s\n%s\n%s", $httpMethod, $contentMD5, $contentType, $requestDateTime, $canonicalPath);
	return $stringToSign;
}

function getSignature($secretAccessKey, $stringToSign) {
	$encodedString = base64_encode($stringToSign);
	$signature = base64_encode(hash_hmac('sha1', $encodedString, $secretAccessKey, $raw_output=true));

	return $signature;
}
?>
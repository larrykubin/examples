﻿using System;

namespace api
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            NinjaApi ninja = new NinjaApi();

            Console.WriteLine("Getting device list");
            string devices = ninja.getDevices();
            Console.WriteLine(devices);

            Console.WriteLine("Getting customer list");
            string customers = ninja.getCustomers();
            Console.WriteLine(customers);
        }
    }
}
